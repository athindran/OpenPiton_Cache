 $('body').ready(function() {
    WaveDrom.ProcessAll();
 });